import {readFile,writeFile,mkdir} from 'node:fs/promises';
const src=new URL('../duo/',import.meta.url),out=new URL('../dist/',import.meta.url);
let html=await readFile(new URL('index.html',src),'utf8');
for(const [mark,file] of [['CONFIG','config.js'],['ART','art.js'],['GAME','game.js']]){
 const js=await readFile(new URL(file,src),'utf8');html=html.replace('/*'+mark+'*/',()=>js);
}
await mkdir(out,{recursive:true});await writeFile(new URL('index.html',out),html);await writeFile(new URL('.nojekyll',out),'');
await writeFile(new URL('../index.html',import.meta.url),html);
