import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
test('single-file page contains two role selectors, touch controls and online transport',()=>{
 const scripts=Array.from(source.matchAll(/<script>([\s\S]*?)<\/script>/g),m=>m[1]);
 for(const script of scripts)new vm.Script(script);
 assert.equal(scripts.length,3);assert.equal((source.match(/class="choice" data-role=/g)||[]).length,2);
 assert.match(source,/map\.onpointerdown/);assert.match(source,/rest\/v1\/rpc\/portolume_visit/);
 assert.doesNotMatch(source,/sb_secret_|\/\*CONFIG\*\//);
});
