function painter(c){
 const box=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);};
 const oval=(x,y,rx,ry,color)=>{for(let d=-ry;d<=ry;d++){const n=Math.round(rx*Math.sqrt(Math.max(0,1-d*d/(ry+.35)**2)));box(x-n,y+d,2*n+1,1,color);}};
 return {box,oval};
}
function actor(c,x,y,role,step=0,dir=1){
 c.save();c.translate(Math.round(x),Math.round(y));const {box,oval}=painter(c);oval(0,0,8,2,'#677d72');
 if(dir<0)c.scale(-1,1);let b=step?Math.round(Math.sin(step)*1.1):0;
 box(-5,-3,4,3+b,'#323d4a');box(2,-3,4,3-b,'#323d4a');c.translate(0,Math.abs(b)?-1:0);
 if(role==='principessa'){
  oval(0,-20,7,8,'#643e43');box(-7,-19,3,13,'#a85b43');box(4,-19,4,13,'#a85b43');
  box(-4,-23,9,8,'#f4b485');box(-3,-21,8,4,'#ffd4a5');box(2,-21,1,2,'#393443');box(-5,-25,9,3,'#ad6345');
  box(-5,-30,2,5,'#e2a536');box(-1,-32,2,6,'#ffda60');box(4,-30,2,5,'#ecb441');box(-5,-27,11,3,'#ffcd56');box(0,-26,2,2,'#65baa3');
  box(-5,-16,10,6,'#943f64');box(-4,-15,8,5,'#ed8494');box(-6,-15,3,4,'#ffd4a7');box(4,-15,3,4,'#ffd4a7');box(-4,-11,9,2,'#f3c563');
  for(let n=0;n<7;n++){const w=5+Math.floor(n/2);box(-w,-9+n,w*2+1,1,'#943e64');box(-w+1,-9+n,w+4,1,'#e27b91');box(-w+2,-9+n,2,1,'#ffb2a9');}
  box(-8,-3,17,2,'#eed3a4');
 }else{
  box(-5,-17,11,14,'#9c5046');box(-7,-12,3,9,'#d66750');
  box(-5,-16,11,10,'#354b5b');box(-4,-15,9,7,'#769aa8');box(-3,-15,6,2,'#d0e3d5');box(-6,-16,4,4,'#b5cccb');box(3,-16,4,4,'#9ebdc1');box(-4,-8,9,2,'#be935b');
  oval(0,-22,7,6,'#354956');box(-5,-26,9,6,'#a3bfc3');box(-4,-26,5,2,'#e1edda');box(-4,-22,11,4,'#454d58');box(0,-21,6,1,'#e3b987');box(3,-20,1,1,'#393743');box(-6,-19,13,2,'#8faeb3');
  box(-2,-29,5,3,'#82434c');box(0,-32,6,4,'#b74950');box(4,-33,6,3,'#ec795d');box(8,-31,3,3,'#bc5052');
  box(-9,-14,7,8,'#3b545e');box(-8,-13,5,7,'#e2b75f');box(-7,-12,3,5,'#477d82');box(-7,-6,3,2,'#8f774a');
 }c.restore();
}
function courtyard(c){
 const {box,oval}=painter(c),rand=(i)=>((Math.imul(i+53,2654435761)>>>0)%1000)/1000;
 box(0,0,260,184,'#9dd4cd');box(0,29,260,22,'#80b3aa');
 for(let i=0;i<32;i++){let x=i*9,y=23+Math.floor(rand(i)*12);oval(x,y+14,12,13,'#75a79a');}
 box(0,50,260,134,'#96b87c');box(0,79,260,8,'#719875');
 for(let i=0;i<550;i++){let x=Math.floor(rand(i*7)*260),y=77+Math.floor(rand(i*13+8)*105);box(x,y,2,1,i%4?'#89ab75':'#b4c68a');}
 box(0,44,260,32,'#8b8f84');box(0,42,260,29,'#cbbfa2');
 for(let i=0;i<26;i++){box(i*11,36,7,8,'#8d948a');box(i*11+1,36,6,7,'#e1d3ae');}
 for(let i=0;i<75;i++){const y=45+Math.floor(i/21)*7,x=(i%21)*13+(Math.floor(i/21)%2)*5;box(x,y,11,1,'#e1d3b2');box(x+10,y+1,1,5,'#b7ae96');}
 const tower=(x)=>{box(x-10,28,20,45,'#9ba097');box(x-8,28,15,43,'#deceb1');box(x-1,37,4,9,'#536c71');box(x-11,25,22,4,'#5a7777');for(let i=0;i<18;i++){const w=Math.ceil((18-i)*.65);box(x-w,25-i,2*w+1,1,'#487d83');if(w>3)box(x-w+1,25-i,Math.ceil(w*.7),1,'#63a19b');}box(x,1,1,9,'#6b6957');box(x+1,1,7,3,'#d77060');};
 tower(24);tower(236);tower(104);tower(156);
 box(113,38,35,39,'#b2a790');box(116,38,29,39,'#d5c3a2');oval(130,57,11,11,'#64716a');box(119,56,23,20,'#64716a');box(121,55,19,20,'#80775e');
 for(let i=0;i<5;i++)box(122+i*4,53,1,22,'#a69673');
 for(let i=0;i<3;i++)box(112-i*2,74+i*3,37+4*i,3,i%2?'#b7af92':'#ead9b5');
 const path='#decb9f';box(107,83,47,101,path);box(0,120,260,26,path);oval(130,130,75,31,path);
 for(let i=0;i<300;i++){const x=Math.floor(rand(i*3)*260),y=85+Math.floor(rand(i*11)*99);if((x>106&&x<154)||(y>120&&y<146)||((x-130)/73)**2+((y-130)/30)**2<1)box(x,y,3,1,i%2?'#cdbb94':'#eddeb6');}
 const tree=(x,y)=>{oval(x+2,y,9,3,'#799777');box(x-2,y-10,4,10,'#806954');oval(x,y-15,9,13,'#477d70');oval(x-2,y-17,7,11,'#6ca079');oval(x-3,y-22,4,5,'#8bb581');};
 for(const [x,y] of [[10,83],[47,82],[82,84],[177,84],[209,82],[250,84],[8,181],[248,182]])tree(x,y);
 for(const [xx,yy] of [[34,103],[210,103],[33,160],[211,160]]){oval(xx,yy,14,4,'#648c70');for(let i=0;i<12;i++){const x=xx-11+Math.round(rand(i*17)*22),y=yy-5+Math.round(rand(i*5)*5);box(x,y,1,3,'#4d8267');box(x-1,y,3,2,i%3?'#e88776':'#f4ce71');}}
}
