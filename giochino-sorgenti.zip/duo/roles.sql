create schema if not exists portolume;
revoke all on schema portolume from public,anon,authenticated;
create table if not exists portolume.seats (
 room uuid not null, role text not null check(role in ('principessa','cavaliere')),
 token uuid not null, expires timestamptz not null, x real not null, y real not null,
 primary key(room,role), unique(room,token)
);
alter table portolume.seats enable row level security;
create or replace function public.portolume_visit(r uuid,k uuid,op text,wanted text default null,px real default null,py real default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare mine text; seats jsonb; ok boolean:=true;
begin
 if r is null or k is null or op is null or op not in ('watch','claim','pulse','leave') then raise exception 'Invalid request';end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(r::text,0));
 delete from portolume.seats where room=r and expires<=clock_timestamp();
 select role into mine from portolume.seats where room=r and token=k;
 if op='claim' then
   if wanted is null or wanted not in ('principessa','cavaliere') then raise exception 'Unknown role';end if;
   if mine is null then
     insert into portolume.seats values(r,wanted,k,clock_timestamp()+interval '24 seconds',case when wanted='principessa' then 105 else 155 end,135)
       on conflict do nothing returning role into mine;
   end if;
   ok:=mine is not distinct from wanted;
 elsif op='leave' then
   delete from portolume.seats where room=r and token=k;mine:=null;
 end if;
 if op in ('claim','pulse') and mine is not null then
   update portolume.seats set expires=clock_timestamp()+interval '24 seconds',
     x=case when px between 12 and 248 then px else x end,
     y=case when py between 86 and 174 then py else y end where room=r and token=k;
 end if;
 select coalesce(jsonb_object_agg(role,jsonb_build_object('x',x,'y',y)), '{}'::jsonb) into seats from portolume.seats where room=r;
 return jsonb_build_object('ok',ok,'mine',mine,'seats',seats);
end;$$;
revoke all on function public.portolume_visit(uuid,uuid,text,text,real,real) from public;
grant execute on function public.portolume_visit(uuid,uuid,text,text,real,real) to anon,authenticated;
