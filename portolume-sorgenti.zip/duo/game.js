(()=>{
 const $=id=>document.getElementById(id),map=$('map'),c=map.getContext('2d'),ground=document.createElement('canvas');
 ground.width=260;ground.height=184;courtyard(ground.getContext('2d'));
 const buttons=[...document.querySelectorAll('.choice')],names={principessa:'Principessa',cavaliere:'Cavaliere'};
 const defaultRoom='7bf8ee50-ccd7-4763-8694-58be9c87fb9c';
 const arg=new URLSearchParams(location.hash.slice(1)).get('partita');
 const room=/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(arg||'')?arg:defaultRoom;
 const token=crypto.randomUUID(),endpoint=service.url+'/rest/v1/rpc/portolume_visit';
 let mine=null,seats={},available=false,pending=false,chain=Promise.resolve(),tasks=0,point=null,me=null,next=0,lastSync=0;
 const displayed={},keys=new Set();
 function update(message=''){
   $('gate').hidden=!!mine;$('leave').hidden=!mine;$('hint').hidden=!mine;$('retry').hidden=available||pending;
   $('status').textContent=available?(Object.keys(seats).length+'/2 online'+(mine?' · '+names[mine]:'')):'Connessione in corso…';
   $('status').parentElement.classList.toggle('online',available);
   for(const b of buttons){const role=b.dataset.role,occupied=!!seats[role];b.disabled=!available||pending||occupied;b.querySelector('.avail').textContent=occupied?'Già scelto':available?'Disponibile':'Verifica…';}
   $('msg').textContent=message||(available?(Object.keys(seats).length===2?'Entrambi i ruoli sono occupati.':'Scegli un ruolo per entrare nel cortile.'):'Verifico i posti sul server…');
 }
 function call(op,wanted=null){
   tasks++;
   const job=chain.then(async()=>{
     const data={r:room,k:token,op,wanted,px:op==='pulse'&&me?me.x:null,py:op==='pulse'&&me?me.y:null};
     const abort=new AbortController(),tm=setTimeout(()=>abort.abort(),6000);
     try{
       const res=await fetch(endpoint,{method:'POST',headers:{apikey:service.key,'Content-Type':'application/json'},body:JSON.stringify(data),signal:abort.signal,cache:'no-store'});
       if(!res.ok)throw Error('Servizio non raggiungibile.');
       const ans=await res.json();if(!ans||!ans.seats||typeof ans.ok!=='boolean')throw Error('Risposta non valida.');
       const old=mine;mine=ans.mine;seats=ans.seats;available=true;lastSync=performance.now();
       if(mine!==old){point=null;keys.clear();me=mine?{...seats[mine],dir:mine==='principessa'?1:-1,phase:0}:null;}
       update(!ans.ok?'Questo ruolo è appena stato scelto. Scegli quello libero.':old&&!mine&&op!=='leave'?'Il posto è scaduto. Scegli di nuovo il personaggio.':'');
     }catch{available=false;update('Connessione assente. Controlla internet e riprova.');}
     finally{clearTimeout(tm);tasks--;}
   });chain=job.catch(()=>{});return job;
 }
 for(const b of buttons){actor(b.querySelector('canvas').getContext('2d'),19,35,b.dataset.role);b.onclick=async()=>{
   if(pending||mine||!available)return;pending=true;update('Prenotazione del posto…');await call('claim',b.dataset.role);pending=false;update();
 };}
 $('leave').onclick=async()=>{if(pending)return;pending=true;point=null;await call('leave');pending=false;update();};
 $('retry').onclick=()=>call(mine?'pulse':'watch');
 $('share').onclick=async()=>{
   let url;if(location.protocol==='file:'){url='Apri lo stesso file Portolume.html sul secondo dispositivo.';}else{const u=new URL(location.href);u.hash='partita='+room;url=u.href;}
   try{if(location.protocol==='file:')throw Error();await navigator.clipboard.writeText(url);$('share').textContent='Link copiato';setTimeout(()=>$('share').textContent='Copia link partita',1600);}
   catch{$('linkbox').hidden=false;const el=$('linkbox').querySelector('input');el.value=url;el.select();}
 };
 const limit=(n,l,h)=>Math.max(l,Math.min(h,n));
 map.onpointerdown=e=>{if(!mine||!available)return;e.preventDefault();const rect=map.getBoundingClientRect(),x=(e.clientX-rect.left)*260/rect.width,y=(e.clientY-rect.top)*184/rect.height;if(y<82)return;point={x:limit(x,12,248),y:limit(y,86,174)};};
 const moves={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]};
 window.addEventListener('keydown',e=>{if(mine&&moves[e.key]){e.preventDefault();keys.add(e.key);point=null;}});
 window.addEventListener('keyup',e=>keys.delete(e.key));
 window.addEventListener('blur',()=>{keys.clear();point=null;});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!tasks)call(mine?'pulse':'watch');});
 window.addEventListener('pagehide',()=>{if(mine)fetch(endpoint,{method:'POST',headers:{apikey:service.key,'Content-Type':'application/json'},body:JSON.stringify({r:room,k:token,op:'leave'}),keepalive:true}).catch(()=>{});});
 function tick(){if(!pending&&!tasks&&performance.now()>=next){next=performance.now()+(mine?(point||keys.size?135:380):1150);call(mine?'pulse':'watch');}}
 setInterval(tick,80);tick();
 let then=performance.now();
 function render(now){
   const dt=Math.min(.12,(now-then)/1000);then=now;
   if(mine&&me&&available){
     let dx=0,dy=0,dist=Infinity;
     if(point){dx=point.x-me.x;dy=point.y-me.y;dist=Math.hypot(dx,dy);}
     else for(const k of keys){dx+=moves[k][0];dy+=moves[k][1];}
     const len=Math.hypot(dx,dy);
     if(len>.01){const n=Math.min(48*dt,dist);me.x=limit(me.x+dx/len*n,12,248);me.y=limit(me.y+dy/len*n,86,174);if(Math.abs(dx)>.1)me.dir=dx>0?1:-1;me.phase+=dt*13;if(dist<=n+.1)point=null;}
     else{me.phase=0;point=null;}
   }
   c.drawImage(ground,0,0);
   if(point&&mine){const {box}=painter(c);box(Math.round(point.x)-3,Math.round(point.y),7,1,'#fff7d2');box(Math.round(point.x),Math.round(point.y)-3,1,7,'#fff7d2');}
   const figures=[];
   for(const [role,pos] of Object.entries(seats)){
     if(role===mine&&me){figures.push({role,...me});continue;}
     let d=displayed[role];if(!d)d=displayed[role]={...pos,dir:1,phase:0};
     const dx=pos.x-d.x,dy=pos.y-d.y,k=1-Math.exp(-dt*12);
     if(Math.abs(dx)>.25)d.dir=dx>0?1:-1;d.phase=Math.hypot(dx,dy)>.3?d.phase+dt*13:0;d.x+=dx*k;d.y+=dy*k;figures.push({role,...d});
   }
   for(const r of Object.keys(displayed))if(!seats[r])delete displayed[r];
   for(const f of figures.sort((a,b)=>a.y-b.y)){actor(c,f.x,f.y,f.role,f.phase,f.dir);if(f.role===mine){const {box}=painter(c);box(Math.round(f.x)-2,Math.round(f.y)-37,5,1,'#fff2a6');box(Math.round(f.x)-1,Math.round(f.y)-36,3,1,'#fff2a6');}}
   requestAnimationFrame(render);
 }
 requestAnimationFrame(render);
})();
